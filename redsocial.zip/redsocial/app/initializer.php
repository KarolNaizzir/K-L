<?php


require_once 'config/config.php';



spl_autoload_register(function($files){
    require_once 'libs/' . $files . '.php';
});