<?php require_once('../app/views/custom/header.php'); ?>

<style>
/* Adaptación del CSS para la página de perfil */

/* Reutilizamos estilos generales */
body {
    background-color: #f5f5f5;
    color: #333;
    font-family: 'Segoe UI', sans-serif;
    margin: 0;
    padding: 0;
}

/* Barra superior igual que la anterior */
.top-bar {
    background: #ffffff;
    padding: 15px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    position: sticky;
    top: 0;
    z-index: 100;
    gap: 20px;
    flex-wrap: nowrap;
}

.top-bar-left a.logout-btn {
    color: #444;
    text-decoration: none;
    font-weight: 600;
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: color 0.3s ease;
}

.top-bar-left a.logout-btn:hover {
    color: #6a5eff;
}

.top-bar-icons a {
    color: #555;
    font-weight: 600;
    margin: 0 12px;
    text-decoration: none;
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: color 0.3s ease;
}

.top-bar-icons a:hover {
    color: #6a5eff;
}

.top-bar-right .welcome-msg {
    font-weight: 600;
    font-size: 1rem;
    color: #6a5eff;
}

/* Contenedor principal perfil */
.perfil-container {
    display: flex;
    gap: 40px;
    padding: 20px 40px;
    flex-wrap: wrap;
    justify-content: center;
}

/* Formulario perfil (izquierda) */
.perfil-formulario {
    background-color: #fff;
    padding: 25px 30px;
    border-radius: 12px;
    box-shadow: 0 0 12px rgba(106, 94, 255, 0.15);
    min-width: 320px;
    max-width: 400px;
    flex: 1;
    color: #333;
}

.perfil-formulario h2 {
    margin-bottom: 20px;
    color: #6a5eff;
    font-weight: 700;
    font-size: 1.5rem;
}

.perfil-formulario label {
    display: block;
    margin-top: 15px;
    margin-bottom: 6px;
    font-weight: 600;
}

.perfil-formulario input[type="text"],
.perfil-formulario textarea {
    width: 100%;
    padding: 10px 14px;
    border: 1.5px solid #ccc;
    border-radius: 12px;
    font-size: 1rem;
    font-family: 'Segoe UI', sans-serif;
    outline: none;
    transition: border-color 0.3s ease;
    resize: vertical;
}

.perfil-formulario input[type="text"]:focus,
.perfil-formulario textarea:focus {
    border-color: #6a5eff;
    box-shadow: 0 0 8px #6a5effaa;
}

.perfil-formulario textarea {
    min-height: 80px;
}

.foto-perfil {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 15px;
}

.foto-perfil img {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #6a5eff;
}

.foto-perfil input[type="file"] {
    font-size: 0.9rem;
    color: #666;
}

.btn-guardar {
    margin-top: 20px;
    background-color: #6a5eff;
    border: none;
    padding: 12px 25px;
    border-radius: 12px;
    color: white;
    font-weight: 700;
    cursor: pointer;
    box-shadow: 0 0 10px #6a5effaa;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
}

.btn-guardar:hover {
    background-color: #5548c8;
    box-shadow: 0 0 15px #5548c8aa;
}

/* Información perfil y publicaciones (derecha) */
.perfil-info {
    background-color: #fff;
    padding: 25px 30px;
    border-radius: 12px;
    box-shadow: 0 0 12px rgba(106, 94, 255, 0.15);
    min-width: 320px;
    max-width: 600px;
    flex: 2;
    color: #333;
}

.perfil-info h2, .perfil-info h3 {
    color: #6a5eff;
    font-weight: 700;
    margin-bottom: 15px;
}

.perfil-info p {
    margin-bottom: 10px;
    line-height: 1.4;
}

.perfil-info form textarea {
    width: 100%;
    padding: 12px 14px;
    border: 2px solid #6a5eff;
    border-radius: 12px;
    resize: vertical;
    font-size: 1rem;
    font-family: 'Segoe UI', sans-serif;
    outline: none;
    transition: border-color 0.3s ease;
}

.perfil-info form textarea:focus {
    border-color: #5548c8;
    box-shadow: 0 0 8px #5548c8aa;
}

.btn-publicar {
    margin-top: 12px;
    background-color: #6a5eff;
    border: none;
    padding: 10px 22px;
    border-radius: 12px;
    color: white;
    font-weight: 700;
    cursor: pointer;
    box-shadow: 0 0 10px #6a5effaa;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
}

.btn-publicar:hover {
    background-color: #5548c8;
    box-shadow: 0 0 15px #5548c8aa;
}

/* Publicaciones */
.perfil-publicaciones {
    margin-top: 20px;
}

.post {
    background-color: #fafafa;
    border-radius: 12px;
    padding: 15px 18px;
    margin-bottom: 18px;
    box-shadow: 0 0 8px rgba(106, 94, 255, 0.15);
    color: #333;
}

.post-header {
    font-size: 0.85rem;
    color: #666;
    margin-bottom: 8px;
}

.post-content {
    font-size: 1rem;
    white-space: pre-wrap;
}

.no-posts {
    color: #999;
    font-style: italic;
    margin-top: 12px;
}

/* Responsive */
@media (max-width: 768px) {
    .perfil-container {
        flex-direction: column;
        padding: 20px 25px;
    }

    .perfil-formulario, .perfil-info {
        max-width: 100%;
    }

    .top-bar {
        padding: 12px 20px;
        flex-wrap: wrap;
    }

    .top-bar-icons {
        margin: 10px 0;
        justify-content: center;
        width: 100%;
        display: flex;
        gap: 15px;
    }
}
</style>

<header class="top-bar">
    <div class="top-bar-left">
        <a href="<?php echo URL_PROJECT; ?>/home/logout" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i> Cerrar sesión
        </a>
    </div>

    <nav class="top-bar-icons">
        <a href="<?php echo URL_PROJECT; ?>/home"><i class="fas fa-home"></i> Inicio</a>
        <a href="<?php echo URL_PROJECT; ?>/home/perfil"><i class="fas fa-user"></i> Perfil</a>
        <a href="<?php echo URL_PROJECT; ?>/home/amigos"><i class="fas fa-user-friends"></i> Amigos</a>
    </nav>

    <div class="top-bar-right">
        <span class="welcome-msg">Hola, <?php echo htmlspecialchars($_SESSION['usuario']); ?></span>
    </div>
</header>

<div class="perfil-container">

    <!-- Columna izquierda: Formulario edición perfil -->
    <div class="perfil-formulario">
        <h2>Editar perfil</h2>
        <form action="<?php echo URL_PROJECT; ?>/home/actualizar" method="POST" enctype="multipart/form-data">
            <div class="foto-perfil">
                <img src="<?php echo URL_PROJECT ?>/public/img/perfiles/<?php echo $datos['usuario']->foto ?? 'default.png'; ?>" alt="Foto de perfil">
                <input type="file" name="foto" accept="image/*">
            </div>

            <label for="nombre">Nombre de usuario</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($datos['usuario']->nombre); ?>" required>

            <label for="biografia">Biografía</label>
            <textarea id="biografia" name="biografia"><?php echo htmlspecialchars($datos['usuario']->biografia ?? ''); ?></textarea>

            <button type="submit" class="btn-guardar">Guardar cambios</button>
        </form>
    </div>

    <!-- Columna derecha: Info perfil y publicaciones -->
    <div class="perfil-info">
        <h2>Tu perfil</h2>
        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($datos['usuario']->nombre); ?></p>
        <p><strong>Biografía:</strong> <?php echo nl2br(htmlspecialchars($datos['usuario']->biografia ?? '')); ?></p>

        <h3>Crear nueva publicación</h3>
        <form action="<?php echo URL_PROJECT; ?>/home/crearPublicacion" method="POST">
            <textarea name="contenido" rows="4" placeholder="¿Qué estás pensando, <?php echo htmlspecialchars($datos['usuario']->nombre); ?>?" required></textarea>
            <button type="submit" class="btn-publicar">Publicar</button>
        </form>

        <h3>Publicaciones</h3>
        <div class="perfil-publicaciones">
            <?php if (!empty($datos['publicaciones'])): ?>
                <?php foreach ($datos['publicaciones'] as $publicacion): ?>
                    <div class="post">
                        <div class="post-header">
                            <?php echo htmlspecialchars($publicacion->fechaPublicacion); ?>
                        </div>
                        <div class="post-content">
                            <?php echo nl2br(htmlspecialchars($publicacion->contenidoPublicacion)); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="no-posts">No has publicado nada aún.</p>
            <?php endif; ?>
        </div>
    </div>

</div>

<?php require_once('../app/views/custom/footer.php'); ?>
