<?php require_once('../app/views/custom/header.php'); ?>

<style>
/* Barra superior igual que la de perfil */
.top-bar {
    background: #ffffff;
    padding: 15px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    position: sticky;
    top: 0;
    z-index: 100;
    gap: 20px;
    flex-wrap: nowrap;
}

.top-bar-left a.logout-btn {
    color: #444;
    text-decoration: none;
    font-weight: 600;
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: color 0.3s ease;
}

.top-bar-left a.logout-btn:hover {
    color: #6a5eff;
}

.top-bar-icons a {
    color: #555;
    font-weight: 600;
    margin: 0 12px;
    text-decoration: none;
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: color 0.3s ease;
}

.top-bar-icons a:hover {
    color: #6a5eff;
}

.top-bar-right .welcome-msg {
    font-weight: 600;
    font-size: 1rem;
    color: #6a5eff;
}

/* Contenedor principal para buscar */
.main-container {
    max-width: 700px;
    margin: 40px auto 80px auto;
    padding: 0 20px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Título */
h2 {
    color: #6a5eff;
    font-weight: 700;
    text-align: center;
    margin-bottom: 25px;
}

/* Formulario de búsqueda */
form {
    display: flex;
    justify-content: center;
    margin-bottom: 30px;
    gap: 12px;
}

input[type="text"] {
    flex: 1;
    max-width: 400px;
    padding: 12px 18px;
    font-size: 1rem;
    border-radius: 30px;
    border: 2px solid #ccc;
    outline: none;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

input[type="text"]:focus {
    border-color: #6a5eff;
    box-shadow: 0 0 12px #6a5eff88;
}

/* Botón Buscar */
button[type="submit"] {
    background-color: #6a5eff;
    color: white;
    border: none;
    border-radius: 30px;
    padding: 12px 24px;
    font-weight: 700;
    cursor: pointer;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
    box-shadow: 0 0 10px #6a5effaa;
}

button[type="submit"]:hover {
    background-color: #5548c8;
    box-shadow: 0 0 15px #5548c8cc;
}

/* Mensaje de éxito */
.success-message {
    color: #27ae60;
    font-weight: 700;
    text-align: center;
    margin-bottom: 20px;
}

/* Resultados contenedor */
.results-container {
    background-color: #fff;
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(106, 94, 255, 0.15);
    padding: 25px 30px;
}

/* Subtítulo resultados */
.results-container h3 {
    color: #6a5eff;
    font-weight: 700;
    margin-bottom: 20px;
    text-align: center;
}

/* Lista de usuarios */
ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
}

ul li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #f9f9ff;
    margin-bottom: 12px;
    padding: 12px 18px;
    border-radius: 12px;
    box-shadow: 0 2px 6px rgba(106, 94, 255, 0.08);
    font-weight: 600;
    font-size: 1rem;
}

/* Formularios botones en línea */
ul li form {
    margin: 0;
    display: flex;
    gap: 6px;
}

/* Botones Enviar solicitud y Mensaje: más pequeños */
ul li form button {
    background-color: #6a5eff;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 6px 12px;
    font-weight: 500;
    font-size: 0.9rem;
    cursor: pointer;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
    white-space: nowrap;
}

ul li form button:first-child {
    background-color: #a29bfe;
}

ul li form button:first-child:hover {
    background-color: #816dfc;
    box-shadow: 0 0 8px #816dfcaa;
}

ul li form button:last-child:hover {
    background-color: #4a90e2;
    box-shadow: 0 0 8px #4a90e2aa;
}

/* Mensaje de no resultados */
.no-results {
    color: #999;
    font-style: italic;
    text-align: center;
    margin-top: 20px;
}

/* Responsive */
@media (max-width: 600px) {
    .top-bar {
        padding: 12px 20px;
        flex-wrap: wrap;
    }

    .top-bar-icons {
        margin: 10px 0;
        justify-content: center;
        width: 100%;
        display: flex;
        gap: 15px;
    }

    .main-container {
        margin: 20px 15px 60px 15px;
    }

    ul li {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
    }

    ul li form {
        width: 100%;
        justify-content: flex-start;
    }

    ul li form button {
        flex: unset;
    }
}
</style>

<header class="top-bar">
    <div class="top-bar-left">
        <a href="<?php echo URL_PROJECT; ?>/home/logout" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i> Cerrar sesión
        </a>
    </div>

    <nav class="top-bar-icons">
        <a href="<?php echo URL_PROJECT; ?>/home"><i class="fas fa-home"></i> Inicio</a>
        <a href="<?php echo URL_PROJECT; ?>/home/perfil"><i class="fas fa-user"></i> Perfil</a>
        <a href="<?php echo URL_PROJECT; ?>/home/amigos"><i class="fas fa-user-friends"></i> Amigos</a>
    </nav>

    <div class="top-bar-right">
        <span class="welcome-msg">Hola, <?php echo htmlspecialchars($_SESSION['usuario']); ?></span>
    </div>
</header>

<div class="main-container">

    <h2>Buscar Amigos</h2>

    <?php if (isset($_SESSION['solicitud_enviada'])) : ?>
        <p class="success-message">
            <?= $_SESSION['solicitud_enviada']; ?>
        </p>
        <?php unset($_SESSION['solicitud_enviada']); ?>
    <?php endif; ?>

    <form method="GET" action="">
        <input type="text" name="buscar" placeholder="Buscar por nombre o apellido" required>
        <button type="submit">Buscar</button>
    </form>

    <?php if (!empty($datos['usuarios'])) : ?>
        <div class="results-container">
            <h3>Resultados de la búsqueda:</h3>
            <ul>
                <?php foreach ($datos['usuarios'] as $usuario) : ?>
                    <li>
                        <?= htmlspecialchars($usuario->usuario) ?>
                        <?php if ($usuario->idusuario !== $_SESSION['idusuario']) : ?>
                            <form action="<?php echo URL_PROJECT ?>/home/enviarSolicitud/<?php echo $usuario->idusuario; ?>" method="POST">
                                <button type="submit">Enviar solicitud</button>
                                <button type="submit">Mensaje</button>
                            </form>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php elseif (isset($_GET['buscar'])) : ?>
        <p class="no-results">No se encontraron usuarios con ese nombre o apellido.</p>
    <?php endif; ?>

</div>

<?php require_once('../app/views/custom/footer.php'); ?>
