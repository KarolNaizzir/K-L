<h2>Chat con <?= htmlspecialchars($amigo->usuario) ?></h2>

<div style="border: 1px solid #ccc; padding: 10px; max-height: 300px; overflow-y: scroll; margin-bottom: 10px;">
    <?php foreach ($mensajes as $msg): ?>
        <p><strong><?= $msg->emisor == $_SESSION['idusuario'] ? 'Tú' : htmlspecialchars($amigo->usuario) ?>:</strong> <?= htmlspecialchars($msg->mensaje) ?></p>
    <?php endforeach; ?>
</div>

<form action="<?= URL_PROJECT ?>/home/enviarMensaje" method="POST">
    <input type="hidden" name="receptor" value="<?= $idAmigo ?>">
    <textarea name="mensaje" rows="3" cols="50" required></textarea><br>
    <button type="submit">Enviar</button>
</form>
