<?php require_once('../app/views/custom/header.php'); ?>

<style>
/* Contenedor principal */
.main-container {
    max-width: 600px;
    margin: 40px auto;
    padding: 0 20px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(106, 94, 255, 0.15);
    padding: 30px;
}

/* Formulario */
form {
    display: flex;
    gap: 10px;
    margin-bottom: 30px;
}

input[type="text"] {
    flex: 1;
    padding: 12px 16px;
    font-size: 1rem;
    border-radius: 30px;
    border: 2px solid #ccc;
    outline: none;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

input[type="text"]:focus {
    border-color: #6a5eff;
    box-shadow: 0 0 12px #6a5eff88;
}

button[type="submit"] {
    background-color: #6a5eff;
    color: white;
    border: none;
    border-radius: 30px;
    padding: 12px 25px;
    font-weight: 700;
    cursor: pointer;
    box-shadow: 0 0 10px #6a5effaa;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
}

button[type="submit"]:hover {
    background-color: #5548c8;
    box-shadow: 0 0 15px #5548c8cc;
}

/* Resultado usuario */
.user-result {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #f9f9ff;
    padding: 12px 20px;
    border-radius: 12px;
    margin-bottom: 15px;
    box-shadow: 0 2px 8px rgba(106, 94, 255, 0.1);
}

.user-result p {
    margin: 0;
    font-weight: 600;
    font-size: 1.1rem;
    color: #333;
}

/* Enviar solicitud link styled as button */
.user-result a {
    background-color: #a29bfe;
    color: white;
    padding: 8px 16px;
    border-radius: 12px;
    font-weight: 600;
    text-decoration: none;
    transition: background-color 0.3s ease;
    white-space: nowrap;
}

.user-result a:hover {
    background-color: #816dfc;
}

/* Mensaje sin resultados */
.no-results {
    text-align: center;
    color: #999;
    font-style: italic;
    margin-top: 20px;
    font-size: 1rem;
}
</style>

<div class="main-container">

    <form action="<?php echo URL_PROJECT ?>/home/buscar" method="POST">
        <input type="text" name="nombre" placeholder="Buscar usuario..." required>
        <button type="submit">Buscar</button>
    </form>

    <?php if (!empty($datos['usuarios'])): ?>
        <?php foreach ($datos['usuarios'] as $usuario): ?>
            <div class="user-result">
                <p><?php echo htmlspecialchars($usuario->nombre); ?></p>
                <a href="<?php echo URL_PROJECT ?>/relacion/enviarSolicitud/<?php echo $usuario->idusuario; ?>">Enviar solicitud</a>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p class="no-results">No se encontraron usuarios.</p>
    <?php endif; ?>

</div>

<?php require_once('../app/views/custom/footer.php'); ?>
