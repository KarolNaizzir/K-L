<?php require_once('../app/views/custom/header.php'); ?>

<style>
body {
    background-color: #f5f5f5;
    color: #333;
    font-family: 'Segoe UI', sans-serif;
    margin: 0;
    padding: 0;
}

.top-bar {
    background: #ffffff;
    padding: 15px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    position: sticky;
    top: 0;
    z-index: 100;
    gap: 20px;
    flex-wrap: nowrap;
}

.top-bar-left, .top-bar-center, .top-bar-right {
    display: flex;
    align-items: center;
    gap: 20px;
}

.top-bar-left a {
    color: #444;
    text-decoration: none;
    font-weight: 600;
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: color 0.3s ease;
}

.top-bar-left a:hover {
    color: #6a5eff;
}

.top-bar-center {
    flex-grow: 1;
    justify-content: center;
    gap: 25px;
}

.top-bar-center h3 {
    color: #6a5eff;
    font-weight: 700;
    font-size: 1.6rem;
    margin: 0;
    user-select: none;
}

.top-bar-center form {
    display: flex;
    align-items: center;
    gap: 8px;
}

.top-bar-center form input[type="text"] {
    padding: 8px 14px;
    border: 1.5px solid #ccc;
    border-radius: 20px;
    outline: none;
    font-size: 1rem;
    width: 200px;
    transition: border-color 0.3s ease;
    background-color: #fff;
    color: #444;
}

.top-bar-center form input[type="text"]:focus {
    border-color: #6a5eff;
    box-shadow: 0 0 5px 1px #6a5effaa;
}

.top-bar-center form button {
    background-color: transparent;
    border: none;
    color: #6a5eff;
    font-size: 1.2rem;
    cursor: pointer;
    transition: color 0.3s ease;
}

.top-bar-center form button:hover {
    color: #4b3dbb;
}

.top-bar-icons a {
    margin: 0 8px;
    font-size: 1.4rem;
    color: #555;
    transition: color 0.3s ease;
}

.top-bar-icons a:hover {
    color: #6a5eff;
}

.top-bar-right .welcome-msg {
    font-weight: 600;
    font-size: 1rem;
    color: #6a5eff;
}

/* Main container */
.main-container {
    display: flex;
    flex-wrap: wrap;
    padding: 20px 40px;
    gap: 20px;
    justify-content: space-between;
}

/* Panels actualizados */
.left-panel {
    flex: 3; /* 75% */
    background-color: #fff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 0 12px rgba(106, 94, 255, 0.15);
    min-width: 320px;
    color: #333;
}

.right-panel {
    flex: 1; /* 25% */
    background-color: #fff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 0 12px rgba(106, 94, 255, 0.15);
    min-width: 280px;
    color: #333;
}

/* Post box */
.post-box textarea {
    width: 100%;
    border: 2px solid #6a5eff;
    border-radius: 10px;
    padding: 12px;
    background-color: #fafafa;
    color: #333;
    resize: none;
    font-size: 1rem;
    font-family: 'Segoe UI', sans-serif;
}

.post-box button {
    background-color: #6a5eff;
    border: none;
    padding: 10px 20px;
    border-radius: 10px;
    color: white;
    font-weight: bold;
    margin-top: 10px;
    box-shadow: 0 0 10px #6a5effaa;
    transition: 0.3s ease;
    cursor: pointer;
}

.post-box button:hover {
    background-color: #5548c8;
    box-shadow: 0 0 15px #5548c8aa;
}

/* Cards */
.card {
    background-color: #fafafa;
    border-radius: 12px;
    padding: 15px;
    margin-bottom: 20px;
    box-shadow: 0 0 10px rgba(106, 94, 255, 0.15);
    transition: transform 0.2s ease;
    color: #333;
}

.card:hover {
    transform: scale(1.01);
    box-shadow: 0 0 15px rgba(106, 94, 255, 0.3);
}

.card .btn {
    font-weight: bold;
    padding: 6px 12px;
    border-radius: 10px;
    margin: 4px 6px;
    transition: 0.3s ease;
    cursor: pointer;
    border: 2px solid transparent;
}

.card .btn-outline-primary {
    border-color: #6a5eff;
    color: #6a5eff;
    background-color: transparent;
}

.card .btn-outline-primary:hover {
    background-color: #6a5eff;
    color: #fff;
}

.card .btn-outline-secondary {
    border-color: #999;
    color: #666;
}

.card .btn-outline-secondary:hover {
    background-color: #999;
    color: #fff;
}

.card .btn-outline-success {
    border-color: #28a745;
    color: #28a745;
}

.card .btn-outline-success:hover {
    background-color: #28a745;
    color: #fff;
}

/* Suggestions and Friends */
.suggestion {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid #eee;
    color: #444;
}

.suggestion button {
    background-color: #6a5eff;
    border: none;
    padding: 6px 12px;
    border-radius: 8px;
    color: white;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.suggestion button:hover {
    background-color: #5548c8;
}

.right-panel ul {
    list-style: none;
    padding: 0;
    color: #444;
}

.right-panel ul li {
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.right-panel ul li button {
    background: #3498db;
    color: white;
    border: none;
    border-radius: 6px;
    padding: 4px 8px;
    cursor: pointer;
    font-weight: 600;
}

.right-panel ul li button:hover {
    background: #2980b9;
}

/* Solicitudes */
.solicitud {
    background-color: #fafafa;
    border: 1px solid #ddd;
    padding: 12px;
    border-radius: 10px;
    margin-bottom: 15px;
    color: #333;
}

.solicitud p {
    margin: 0 0 10px 0;
    font-weight: 600;
}

.solicitud form button {
    padding: 6px 12px;
    font-weight: 600;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    margin-right: 8px;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
}

.solicitud form button[name="respuesta"][value="aceptado"] {
    background-color: #28a745;
    color: white;
    box-shadow: 0 0 8px #28a745aa;
}

.solicitud form button[name="respuesta"][value="aceptado"]:hover {
    background-color: #218838;
    box-shadow: 0 0 12px #218838aa;
}

.solicitud form button[name="respuesta"][value="rechazado"] {
    background-color: #dc3545;
    color: white;
    box-shadow: 0 0 8px #dc3545aa;
}

.solicitud form button[name="respuesta"][value="rechazado"]:hover {
    background-color: #c82333;
    box-shadow: 0 0 12px #c82333aa;
}

/* Responsive tweaks */
@media (max-width: 768px) {
    .main-container {
        flex-direction: column;
        padding: 20px 25px;
    }

    .left-panel, .right-panel {
        max-width: 100%;
    }

    .top-bar {
        flex-wrap: wrap;
        padding: 12px 20px;
    }

    .top-bar-center {
        justify-content: flex-start;
        gap: 12px;
        flex-wrap: wrap;
    }

    .top-bar-center form input[type="text"] {
        width: 140px;
    }
}
</style>

<header class="top-bar">
    <div class="top-bar-left">
        <a href="<?php echo URL_PROJECT; ?>/home/logout">
            <i class="fas fa-sign-out-alt"></i> Cerrar sesión
        </a>
    </div>

    <div class="top-bar-center">
        <h3>K&L</h3>
        <form method="POST" action="<?php echo URL_PROJECT; ?>/home/buscarUsuarios">
            <input type="text" name="nombre" placeholder="Buscar por nombre" required>
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
        <nav class="top-bar-icons">
            <a href="<?php echo URL_PROJECT; ?>/home"><i class="fas fa-home"></i></a>
            <a href="<?php echo URL_PROJECT; ?>/home/perfil"><i class="fas fa-user"></i></a>
            <a href="<?php echo URL_PROJECT; ?>/home/amigos"><i class="fas fa-user-friends"></i></a>
        </nav>
    </div>

    <div class="top-bar-right">
        <span class="welcome-msg">Hola, <?php echo htmlspecialchars($_SESSION['usuario']); ?></span>
    </div>
</header>

<div class="main-container">
    <!-- Panel izquierdo (publicaciones) -->
    <div class="left-panel">
        <!-- Publicar -->
        <div class="post-box">
            <form action="<?= URL_PROJECT ?>/home" method="POST">
                <textarea name="contenido" placeholder="¿Qué estás pensando?" required></textarea>
                <button type="submit">Publicar</button>
            </form>
        </div>

        <!-- Mostrar publicaciones -->
        <?php if (!empty($datos['publicaciones']) && is_array($datos['publicaciones'])): ?>
            <?php foreach ($datos['publicaciones'] as $publicacion): ?>
                <div class="card">
                    <div style="display:flex; align-items:center; margin-bottom:10px;">
                        <img src="<?= URL_PROJECT ?>/public/img/perfiles/<?= htmlspecialchars($publicacion->foto ?? 'default.png') ?>"
                             alt="Foto de perfil de <?= htmlspecialchars($publicacion->usuario) ?>"
                             style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover; margin-right: 12px;"
                             onerror="this.onerror=null; this.src='<?= URL_PROJECT ?>/public/img/perfiles/default.png';"
                        >
                        <div>
                            <strong><?= htmlspecialchars($publicacion->usuario) ?></strong><br>
                            <small style="color:#666; font-size:0.85rem;">
                                <?= date('Y-m-d H:i:s', strtotime($publicacion->fechaPublicacion ?? $publicacion->fecha ?? 'now')) ?>
                            </small>
                        </div>
                    </div>
                    <p style="white-space: pre-wrap;"><?= nl2br(htmlspecialchars($publicacion->contenidoPublicacion ?? $publicacion->contenido)) ?></p>
                    <div style="display:flex; justify-content:space-around; border-top:1px solid #ddd; padding-top:8px;">
                        <button class="btn btn-outline-primary btn-sm" type="button">👍 Me gusta</button>
                        <button class="btn btn-outline-secondary btn-sm" type="button">💬 Comentar</button>
                        <button class="btn btn-outline-success btn-sm" type="button">🔗 Compartir</button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No hay publicaciones.</p>
        <?php endif; ?>
    </div>

    <!-- Panel derecho (sugerencias, amigos, solicitudes) -->
    <div class="right-panel">
        <h3>Sugerencias</h3>
        <?php if (!empty($datos['sugerencias'])): ?>
            <?php foreach ($datos['sugerencias'] as $sugerido): ?>
                <div class="suggestion">
                    <span><?= htmlspecialchars($sugerido->usuario) ?></span>
                    <form method="post" action="<?= URL_PROJECT ?>/home/solicitudAmistad" style="display:inline;">
                        <input type="hidden" name="receptor" value="<?= (int)$sugerido->idusuario ?>">
                        <button type="submit">Enviar solicitud</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No hay sugerencias disponibles.</p>
        <?php endif; ?>

        <h3>Amigos</h3>
        <ul>
            <?php if (!empty($datos['amigos']) && is_array($datos['amigos'])): ?>
                <?php foreach ($datos['amigos'] as $amigo): ?>
                    <li>
                        <?= htmlspecialchars($amigo->usuario) ?>
                        <form action="<?= URL_PROJECT ?>/home/chat/<?= (int)$amigo->idusuario ?>" method="GET" style="display:inline;">
                            <button type="submit">Mensaje</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li>No tienes amigos aún.</li>
            <?php endif; ?>
        </ul>

        <h3>Solicitudes Recibidas</h3>
        <?php if (!empty($datos['solicitudes']) && is_array($datos['solicitudes'])): ?>
            <?php foreach ($datos['solicitudes'] as $solicitud): ?>
                <div class="solicitud">
                    <p><?= htmlspecialchars($solicitud->usuario) ?> quiere ser tu amigo</p>
                    <form method="POST" action="<?= RUTA_URL ?>/home/responderSolicitud">
                        <input type="hidden" name="id_solicitud" value="<?= (int)$solicitud->id ?>">
                        <button name="respuesta" value="aceptado" type="submit">Aceptar</button>
                        <button name="respuesta" value="rechazado" type="submit">Rechazar</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No tienes solicitudes pendientes.</p>
        <?php endif; ?>
    </div>
</div>

<?php require_once('../app/views/custom/footer.php'); ?>