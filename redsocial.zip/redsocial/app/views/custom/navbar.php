<header>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">
                <img src="https://cdn.freebiesupply.com/logos/large/2x/facebook-messenger-logo-black-and-white.png" alt="Logo" class="image-logo">
            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" 
                    aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="fas fa-home mr-1"></i>Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="fas fa-users mr-1"></i>Usuarios</a>
                    </li>
                    <li class="nav-item">
                        <form action="" method="get" class="form-inline my-2 my-lg-0">
                            <input class="form-control mr-sm-2" type="search" name="buscar" placeholder="Buscar" aria-label="Buscar">
                            <button class="btn btn-outline-secondary my-2 my-sm-0" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </form>
                    </li>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="far fa-envelope"></i> Mensajes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="fas fa-bell"></i> Notificaciones</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="actionPerfil" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="https://images.unsplash.com/photo-1599566150163-29194dcaad36?crop=faces&fit=crop&h=100&w=100" 
                                 alt="perfil" class="img-fluid rounded-circle mr-2" style="width: 32px; height: 32px;">
                            <?php echo isset($_SESSION['usuario']) ? ucwords($_SESSION['usuario']) : ''; ?>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="actionPerfil">
                            <a class="dropdown-item" href="<?php echo URL_PROJECT ?>/home/logout">Salir</a>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</header>



