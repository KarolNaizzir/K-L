<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo NAME_PROJECT ?></title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/8fe469c166.js" crossorigin="anonymous"></script>

    <!-- CSS personalizado -->
    <link rel="stylesheet" href="<?php echo URL_PROJECT; ?>/public/css/style.css">
    <link rel="stylesheet" href="<?php echo URL_PROJECT; ?>/public/css/home.css">
    <link rel="stylesheet" href="<?= URL_PROJECT ?>/public/css/perfil.css">
    <link rel="stylesheet" href="<?= URL_PROJECT ?>/public/css/amigos.css">

</head>
<body>




