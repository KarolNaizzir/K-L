<?php

class Core
{
    protected $currentController = 'Home'; // Asegúrate que el nombre del archivo sea "Home.php"
    protected $currentMethod = 'index';
    protected $parameters = [];

    public function __construct()
    {
        $url = $this->getUrl(); // ✅ paréntesis para llamar al método

        // ✅ Verificamos si hay un controlador y si existe el archivo
        if (isset($url[0]) && file_exists('../app/controllers/' . ucwords($url[0]) . '.php')) {
            $this->currentController = ucwords($url[0]);
            unset($url[0]);
        }

        // ✅ Cargamos el archivo del controlador actual
        require_once '../app/controllers/' . $this->currentController . '.php';
        $this->currentController = new $this->currentController;

        if (isset($url[1])) {
            if (method_exists($this->currentController, $url[1])) {
                $this->currentMethod = $url[1];
                unset($url[1]);
            }
        }

        // ✅ Los parámetros restantes
        $this->parameters = $url ? array_values($url) : [];

        // ✅ Ejecutar el método con parámetros
        call_user_func_array([$this->currentController, $this->currentMethod], $this->parameters);
    }

    public function getUrl()
    {
        if (isset($_GET['url'])) {
            $url = rtrim($_GET['url'], '/');
            $url = filter_var($url, FILTER_SANITIZE_URL);
            $url = explode('/', $url);
            return $url;
        }
        return []; // ✅ Evita retornar null si no hay URL
    }
}