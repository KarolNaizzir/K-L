<?php

class Base
{
    private $host = DB_HOST;
    private $dbname = DB_NAME;
    private $user = DB_USER;
    private $password = DB_PASSWORD;

    private $dbh;
    private $stmt;
    private $error;

    public function __construct()
    {
        $dsn = 'mysql:host=' . $this->host . ';dbname=' . $this->dbname . ';charset=utf8';

        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
            PDO::ATTR_EMULATE_PREPARES => false
        ];

        try {
            $this->dbh = new PDO($dsn, $this->user, $this->password, $options);
        } catch (PDOException $e) {
            die("❌ Error de conexión: " . $e->getMessage());
        }
    }

    public function query($sql)
    {
        $this->stmt = $this->dbh->prepare($sql);
    }

    public function bind($param, $valor, $tipo = null)
    {
        if (is_null($tipo)) {
            switch (true) {
                case is_int($valor): $tipo = PDO::PARAM_INT; break;
                case is_bool($valor): $tipo = PDO::PARAM_BOOL; break;
                case is_null($valor): $tipo = PDO::PARAM_NULL; break;
                default: $tipo = PDO::PARAM_STR;
            }
        }

        $this->stmt->bindValue($param, $valor, $tipo);
    }

    public function execute()
    {
        return $this->stmt->execute();
    }

    public function registros()
    {
        $this->execute();
        return $this->stmt->fetchAll(); // FETCH_OBJ por defecto
    }

    public function single()
    {
        $this->execute();
        return $this->stmt->fetch();
    }

    public function rowCount()
    {
        return $this->stmt->rowCount();
    }
}