<?php

class Home extends Controller
{
    private $usuario;
    private $perfilModelo;
    private $usuarioModelo;

    public function __construct()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        $this->usuario = $this->model('Usuario');
        $this->perfilModelo = $this->model('PerfilModelo');
        $this->usuarioModelo = $this->model('Usuario'); // ✅ corregido: model(), no modelo()
    }

    public function index()
    {
        if (empty($_SESSION['logueado'])) {
            redirection('/home/login');
        }

        $modeloPublicacion = $this->model('Publicacion');

        // Guardar nueva publicación si se recibe POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contenido'])) {
            $contenido = trim($_POST['contenido']);

            if (!empty($contenido)) {
                $modeloPublicacion->guardar($_SESSION['idusuario'], $contenido);
            }

            redirection('/home');
        }

        $relacionModelo = $this->model('RelacionModelo');
        $solicitudes = $relacionModelo->obtenerSolicitudes($_SESSION['idusuario']);

        // 🔵 Agregar modelos y datos adicionales
        $usuarioModelo = $this->model('Usuario'); // para lista de usuarios
        $amigosModelo = $this->model('RelacionModelo'); // si también se encarga de los amigos

        $usuarios = $usuarioModelo->obtenerUsuarios(); // o ajustar si filtras por nombre
        $amigos = $amigosModelo->obtenerAmigos($_SESSION['idusuario']); // asegúrate de tener esta función

        $datos = [
            'publicaciones' => $modeloPublicacion->obtenerPublicaciones(),
            'solicitudes' => $solicitudes ?? [],
            'usuarios' => $usuarios ?? [],
            'amigos' => $amigos ?? []
        ];

        $this->view('pages/home', $datos);
    }

    public function login()
    {
        if (isset($_SESSION['logueado'])) {
            redirection('/home');
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $datoslogin = [
                'usuario' => trim($_POST['usuario']),
                'contrasena' => trim($_POST['contrasena'])
            ];

            $datosUsuario = $this->usuario->getUsuario($datoslogin['usuario']);

            if ($datosUsuario && $this->usuario->verificarContrasena($datosUsuario, $datoslogin['contrasena'])) {
                $_SESSION['logueado'] = true;
                $_SESSION['usuario'] = $datosUsuario->usuario;
                $_SESSION['idusuario'] = $datosUsuario->idusuario;

                redirection('/home');
            } else {
                $_SESSION['errorLogin'] = 'El usuario o la contraseña son incorrectos';
                redirection('/home/login');
            }
        } else {
            $this->view('pages/login-register/login');
        }
    }

    public function register()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $datosRegistro = [
                'privilegio' => '2',
                'email' => trim($_POST['email']),
                'usuario' => trim($_POST['usuario']),
                'contrasena' => password_hash(trim($_POST['contrasena']), PASSWORD_DEFAULT)
            ];

            if ($this->usuario->verificarUsuario($datosRegistro)) {
                if ($this->usuario->register($datosRegistro)) {
                    $_SESSION['LoginComplete'] = 'Tu registro se ha completado satisfactoriamente, ahora puedes ingresar';
                    redirection('/home/login');
                } else {
                    $_SESSION['registroError'] = 'Error al registrar el usuario.';
                    $this->view('pages/login-register/register');
                }
            } else {
                $_SESSION['usuarioError'] = 'El usuario no está disponible, intenta con otro.';
                $this->view('pages/login-register/register');
            }
        } else {
            if (isset($_SESSION['logueado'])) {
                redirection('/home');
            } else {
                $this->view('pages/login-register/register');
            }
        }
    }

    public function logout()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION = [];
        session_destroy();
        redirection('/home/login');
    }

    public function perfil()
    {
        if (!isset($_SESSION['logueado'])) {
            redirection('/home/login');
        }

        $usuarioId = $_SESSION['idusuario'];

        $usuario = $this->usuario->obtenerUsuarioPorId($usuarioId);
        $modeloPublicacion = $this->model('Publicacion');
        $publicaciones = $modeloPublicacion->obtenerPublicacionesPorUsuario($usuarioId);

        $datos = [
            'usuario' => $usuario,
            'publicaciones' => $publicaciones
        ];

        $this->view('pages/perfil', $datos);
    }

    public function crearPublicacion()
    {
        if (!isset($_SESSION['logueado'])) {
            redirection('/home/login');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $contenido = trim($_POST['contenido']);
            $idUsuario = $_SESSION['idusuario'];

            if (!empty($contenido)) {
                $this->perfilModelo->crearPublicacion($idUsuario, $contenido);
            }
        }

        redirection('/home/perfil');
    }

    public function amigos()
    {
        if (!isset($_SESSION['logueado'])) {
            redirection('/home/login');
        }

        $usuariosEncontrados = [];

        if (isset($_GET['buscar'])) {
            $nombre = trim($_GET['buscar']);
            $usuariosEncontrados = $this->usuario->buscarUsuarios($nombre, $_SESSION['idusuario']);
        }

        $this->view('pages/amigos', ['usuarios' => $usuariosEncontrados]);
    }

    public function actualizar()
    {
        if (!isset($_SESSION['logueado'])) {
            redirection('/home/login');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $idusuario = $_SESSION['idusuario'];
            $nombre = trim($_POST['nombre']);
            $biografia = trim($_POST['biografia']);
            $nombreFoto = null;

            if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
                $nombreOriginal = $_FILES['foto']['name'];
                $extension = strtolower(pathinfo($nombreOriginal, PATHINFO_EXTENSION));
                $tamanoArchivo = $_FILES['foto']['size'];
                $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'gif'];
                $tamanoMaximo = 2 * 1024 * 1024;

                if (in_array($extension, $extensionesPermitidas) && $tamanoArchivo <= $tamanoMaximo) {
                    $nombreFoto = uniqid() . '.' . $extension;
                    $rutaDestino = __DIR__ . '/../../public/img/perfiles/' . $nombreFoto;
                    move_uploaded_file($_FILES['foto']['tmp_name'], $rutaDestino);
                } else {
                    $_SESSION['errorFoto'] = 'La imagen debe ser JPG, JPEG, PNG o GIF y no pesar más de 2 MB.';
                    redirection('/perfil');
                    return;
                }
            }

            $this->usuario->actualizarPerfil($idusuario, $nombre, $biografia, $nombreFoto);
            redirection('/perfil');
        } else {
            redirection('/perfil');
        }
    }

    public function buscar()
    {
        $relacionModelo = $this->model('RelacionModelo');
        $resultados = [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = trim($_POST['nombre']);

            // 👉 esto imprime lo que se recibe desde el input
            echo "<pre>";
            print_r($_POST);
            echo "</pre>";

            $resultados = $relacionModelo->buscarUsuarios($nombre, $_SESSION['idusuario']);
        }

        $this->view('pages/buscar', ['usuarios' => $resultados]);
    }

    public function enviarSolicitud($idReceptor = null)
    {
        if (!isset($_SESSION['logueado'])) {
            redirection('/home/login');
        }

        // Validar si se proporcionó el ID del receptor
        if ($idReceptor === null) {
            $_SESSION['solicitud_enviada'] = 'No se especificó el usuario receptor.';
            redirection('/home/amigos');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $idEmisor = $_SESSION['idusuario'];

            if ($this->usuarioModelo->enviarSolicitud($idEmisor, $idReceptor)) {
                $_SESSION['solicitud_enviada'] = 'Solicitud enviada correctamente';
            } else {
                $_SESSION['solicitud_enviada'] = 'Ya enviaste una solicitud a este usuario o ocurrió un error.';
            }

            redirection('/home/amigos');
        } else {
            redirection('/home/amigos');
        }
    }

    public function responderSolicitud()
    {
        if (!isset($_SESSION['logueado'])) {
            redirection('/home/login');
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $idSolicitud = $_POST['id_solicitud'];
            $respuesta = $_POST['respuesta'];

            if ($this->usuarioModelo->actualizarEstadoSolicitud($idSolicitud, $respuesta)) {
                redirection('/home');
            } else {
                die("No se pudo responder la solicitud.");
            }
        }
    }

    public function chat($idAmigo)
    {
        if (!isset($_SESSION['logueado'])) {
            redirection('/home/login');
        }

        $idUsuario = $_SESSION['idusuario'];
    
        $mensajes = $this->usuarioModelo->obtenerMensajes($idUsuario, $idAmigo);
        $amigo = $this->usuarioModelo->obtenerUsuarioPorId($idAmigo);

        $this->view('pages/chat', [
            'mensajes' => $mensajes,
            'amigo' => $amigo,
            'idAmigo' => $idAmigo
        ]);
    }

    public function enviarMensaje()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $emisor = $_SESSION['idusuario'];
            $receptor = $_POST['receptor'];
            $mensaje = trim($_POST['mensaje']);

            if ($this->usuarioModelo->guardarMensaje($emisor, $receptor, $mensaje)) {
                redirection("/home/chat/$receptor");
            } else {
                die("Error al enviar mensaje.");
            }
        } else {
            redirection('/home/amigos');
        }
    }
}