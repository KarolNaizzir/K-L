<?php

define('RUTA', 'http://localhost/redsocial/public');
define('RUTA_URL', 'http://localhost/redsocial'); 


define('DB_HOST' , 'localhost');
define('DB_NAME' , 'redsocial');
define('DB_USER' , 'root');
define('DB_PASSWORD' , '');



define('URL_APP' , dirname(dirname(__FILE__)));
define('URL_PROJECT' , 'http://localhost/redsocial');
define('NAME_PROJECT' , 'Red Social');