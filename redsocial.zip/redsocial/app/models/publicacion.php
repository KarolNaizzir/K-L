<?php

class Publicacion
{
    private $db;

    public function __construct()
    {
        $this->db = new Base;
    }

    public function obtenerPublicaciones()
    {
        $this->db->query("
            SELECT p.*, u.usuario 
            FROM publicaciones p 
            INNER JOIN usuarios u ON p.idUserPublico = u.idusuario 
            ORDER BY p.fechaPublicacion DESC
        ");
        return $this->db->registros(); // ✅ Asegúrate que este método devuelve un array de objetos
    }
public function obtenerUsuariosSugeridos($idUsuarioActual)
{
    $this->db->query("SELECT id_usuario, nombre FROM usuarios WHERE id_usuario != :id");
    $this->db->bind(':id', $idUsuarioActual);
    return $this->db->registros(); // Devuelve lista de objetos
}

    public function guardar($idUsuario, $contenido)
    {
        $this->db->query("
            INSERT INTO publicaciones (idUserPublico, contenidoPublicacion, fechaPublicacion) 
            VALUES (:id, :contenido, NOW())
        ");
        $this->db->bind(':id', $idUsuario);
        $this->db->bind(':contenido', $contenido);
        return $this->db->execute();
    }

    public function obtenerPublicacionesPorUsuario($idusuario)
    {
        $this->db->query("
            SELECT contenidoPublicacion, fechaPublicacion 
            FROM publicaciones 
            WHERE idUserPublico = :id 
            ORDER BY fechaPublicacion DESC
        ");
        $this->db->bind(':id', $idusuario);
        return $this->db->registros(); // Asegúrate de que este método existe en tu clase Base.php
    }
   
}