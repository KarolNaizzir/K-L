<?php

class RelacionModelo {
    
    private $db;

    public function __construct() {
        $this->db = new Base;
    }

    public function buscarUsuarios($nombre, $idActual) 
    {
        $this->db->query("SELECT * FROM usuarios WHERE nombre LIKE :nombre AND idusuario != :id");
        $this->db->bind(':nombre', "%$nombre%");
        $this->db->bind(':id', $idActual);
        return $this->db->registros();
    }

    public function enviarSolicitud($idEmisor, $idReceptor) {
        $this->db->query("INSERT INTO solicitudes (id_emisor, id_receptor) VALUES (:idEmisor, :idReceptor)");
        $this->db->bind(':idEmisor', $idEmisor);
        $this->db->bind(':idReceptor', $idReceptor);
        return $this->db->execute();
    }

    public function obtenerAmigos($idUsuario)
    {
        $this->db->query("
            SELECT u.idusuario, u.nombre AS usuario
            FROM amistades a
            JOIN usuarios u 
                ON (u.idusuario = a.receptor_id AND a.solicitante_id = :id1)
                OR (u.idusuario = a.solicitante_id AND a.receptor_id = :id2)
            WHERE a.estado = 'aceptada'
        ");

        $this->db->bind(':id1', $idUsuario);
        $this->db->bind(':id2', $idUsuario);

        return $this->db->registros();
    }

    public function eliminarAmistad($idUsuario1, $idUsuario2)
    {
        $this->db->query("DELETE FROM amistades 
                          WHERE (solicitante_id = :id1 AND receptor_id = :id2) 
                             OR (solicitante_id = :id2 AND receptor_id = :id1)");

        $this->db->bind(':id1', $idUsuario1);
        $this->db->bind(':id2', $idUsuario2);

        return $this->db->execute();
    }


    public function enviarMensaje($emisor, $receptor, $contenido) {
        $this->db->query("INSERT INTO mensajes (id_emisor, id_receptor, contenido) VALUES (:emisor, :receptor, :contenido)");
        $this->db->bind(':emisor', $emisor);
        $this->db->bind(':receptor', $receptor);
        $this->db->bind(':contenido', $contenido);
        return $this->db->execute();
    }

    public function obtenerMensajes($emisor, $receptor) {
        $this->db->query("
            SELECT * FROM mensajes 
            WHERE (id_emisor = :emisor AND id_receptor = :receptor)
               OR (id_emisor = :receptor AND id_receptor = :emisor)
            ORDER BY fecha ASC
        ");
        $this->db->bind(':emisor', $emisor);
        $this->db->bind(':receptor', $receptor);
        return $this->db->registros();
    }

    // ✅ NUEVO MÉTODO para obtener solicitudes pendientes
    public function obtenerSolicitudes($idUsuario) {
        $this->db->query("
            SELECT s.id, u.usuario, u.idusuario
            FROM solicitudes s
            INNER JOIN usuarios u ON s.id_emisor = u.idusuario
            WHERE s.id_receptor = :idUsuario AND s.estado = 'pendiente'
        ");
        $this->db->bind(':idUsuario', $idUsuario);
        return $this->db->registros();
    }
}
