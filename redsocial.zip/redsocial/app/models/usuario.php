<?php

class Usuario
{
    private $db;

    public function __construct()
    {
        $this->db = new Base;
    }

    public function getUsuario($usuario)
    {
        $this->db->query("SELECT idusuario, idPrivilegio, usuario, contrasena 
                          FROM usuarios 
                          WHERE usuario = :usuario");
        $this->db->bind(':usuario', $usuario);
        return $this->db->single();
    }

    public function verificarContrasena($datosUsuario, $contrasena)
    {
        return password_verify($contrasena, $datosUsuario->contrasena);
    }

    public function verificarUsuario($datosUsuario)
    {
        $this->db->query('SELECT usuario FROM usuarios WHERE usuario = :usuario');
        $this->db->bind(':usuario', $datosUsuario['usuario']);
        $this->db->execute();

        return $this->db->rowCount() === 0;
    }

    public function register($datosUsuario)
    {
        $this->db->query('INSERT INTO usuarios (idPrivilegio, correo, usuario, contrasena) 
                          VALUES (:privilegio, :correo, :usuario, :contrasena)');
        $this->db->bind(':privilegio', $datosUsuario['privilegio']);
        $this->db->bind(':correo', $datosUsuario['email']);
        $this->db->bind(':usuario', $datosUsuario['usuario']);
        $this->db->bind(':contrasena', $datosUsuario['contrasena']);

        return $this->db->execute();
    }

    public function guardarMensaje($emisor, $receptor, $mensaje)
    {
        $this->db->query("INSERT INTO mensajes (emisor, receptor, mensaje, fecha) VALUES (:emisor, :receptor, :mensaje, NOW())");
        $this->db->bind(':emisor', $emisor);
        $this->db->bind(':receptor', $receptor);
        $this->db->bind(':mensaje', $mensaje);
        return $this->db->execute();
    }

    public function obtenerMensajes($id1, $id2)
    {
        $this->db->query("SELECT * FROM mensajes 
                          WHERE (emisor = :id1 AND receptor = :id2) 
                             OR (emisor = :id2 AND receptor = :id1)
                          ORDER BY fecha ASC");
        $this->db->bind(':id1', $id1);
        $this->db->bind(':id2', $id2);
        return $this->db->registros();
    }

        public function obtenerUsuarios()
    {
        $this->db->query("SELECT idusuario, nombre FROM usuarios WHERE idusuario != :id");
        $this->db->bind(':id', $_SESSION['idusuario']);
        return $this->db->registros(); // regresa un array de objetos
    }


    public function obtenerUsuarioPorId($id)
    {
        $this->db->query("SELECT idusuario, usuario, nombre, foto, biografia FROM usuarios WHERE idusuario = :id");
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    public function actualizarPerfil($idusuario, $nombre, $biografia, $foto = null)
    {
        if ($foto) {
            $this->db->query("UPDATE usuarios 
                          SET nombre = :nombre, biografia = :biografia, foto = :foto 
                          WHERE idusuario = :id");
            $this->db->bind(':foto', $foto);
        } else {
            $this->db->query("UPDATE usuarios 
                          SET nombre = :nombre, biografia = :biografia 
                          WHERE idusuario = :id");
        }

        $this->db->bind(':nombre', $nombre);
        $this->db->bind(':biografia', $biografia);
        $this->db->bind(':id', $idusuario);

        return $this->db->execute();
    }

    public function obtenerSolicitudesRecibidas($idUsuario)
    {
        $this->db->query("SELECT s.id, u.usuario 
                          FROM solicitudes s 
                          JOIN usuarios u ON s.id_emisor = u.idusuario 
                          WHERE s.id_receptor = :id AND s.estado = 'pendiente'");
        $this->db->bind(':id', $idUsuario);

        return $this->db->registros();
    }

    public function enviarSolicitud($idEmisor, $idReceptor)
    {
        // Verificar si ya existe una solicitud pendiente
        $this->db->query("SELECT * FROM solicitudes 
                          WHERE id_emisor = :emisor AND id_receptor = :receptor AND estado = 'pendiente'");
        $this->db->bind(':emisor', $idEmisor);
        $this->db->bind(':receptor', $idReceptor);
        $this->db->execute();

        if ($this->db->rowCount() > 0) {
            return false; // Ya existe una solicitud pendiente
        }

        $this->db->query("INSERT INTO solicitudes (id_emisor, id_receptor, estado) 
                          VALUES (:emisor, :receptor, 'pendiente')");
        $this->db->bind(':emisor', $idEmisor);
        $this->db->bind(':receptor', $idReceptor);

        return $this->db->execute();
    }

    public function actualizarEstadoSolicitud($idSolicitud, $estado)
    {
        $this->db->query("UPDATE solicitudes SET estado = :estado WHERE id = :id");
        $this->db->bind(':estado', $estado);
        $this->db->bind(':id', $idSolicitud);
        return $this->db->execute();
    }

    public function buscarUsuarios($nombre, $idActual)
    {
        $this->db->query("SELECT * FROM usuarios 
                          WHERE (usuario LIKE :nombre1 OR nombre LIKE :nombre2)
                          AND idusuario != :id");

        $this->db->bind(':nombre1', '%' . $nombre . '%');
        $this->db->bind(':nombre2', '%' . $nombre . '%');
        $this->db->bind(':id', $idActual);

        return $this->db->registros(); // ✅ esto faltaba
    }
}