<?php

class PerfilModelo
{
    private $db;

    public function __construct()
    {
        $this->db = new Base; // Asume que tienes una clase Base para DB
    }

    public function crearPublicacion($idUsuario, $contenido)
    {
        $this->db->query("INSERT INTO publicaciones (idUserPublico, contenidoPublicacion, fechaPublicacion) VALUES (:id, :contenido, NOW())");
        $this->db->bind(':id', $idUsuario);
        $this->db->bind(':contenido', $contenido);

        return $this->db->execute();
    }

    public function obtenerPublicacionesPorUsuario($idUsuario)
    {
        $this->db->query("SELECT * FROM publicaciones WHERE idUserPublico = :id ORDER BY fechaPublicacion DESC");
        $this->db->bind(':id', $idUsuario);

        return $this->db->registros();
    }
}
