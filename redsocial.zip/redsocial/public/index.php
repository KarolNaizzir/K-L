<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../app/initializer.php';
require_once '../app/helpers/url_helpers.php';

$init = new Core;
